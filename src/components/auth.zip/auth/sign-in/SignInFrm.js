import React, { useEffect, useState } from "react";
import {
  CustomColouredTypography,
  CustomLink,
  CustomStackFullWidth,
  CustomTypographyGray,
} from "../../../styled-components/CustomStyles.style";
import CloseIcon from "@mui/icons-material/Close";
import CustomPhoneInput from "../../custom-component/CustomPhoneInput";
import CustomTextFieldWithFormik from "../../form-fields/CustomTextFieldWithFormik";
import { t } from "i18next";
import AuthHeader from "../AuthHeader";
import { getLanguage } from "../../../helper-functions/getLanguage";
import SinUp from "../asset/signup.png";
import LockIcon from "@mui/icons-material/Lock";
import {
  InputAdornment,
  alpha,
  useTheme,
  FormControlLabel,
  Checkbox,
  Typography,
  Box,
  IconButton,
} from "@mui/material";
import CustomPhoneInputManual from "components/custom-component/CustomPhoneInputManual";
import { checkInput } from "utils/CustomFunctions";
import toast from "react-hot-toast";
import { CustomTypography } from "components/landing-page/hero-section/HeroSection.style";
import LoadingButton from "@mui/lab/LoadingButton";
import { loadRememberMePreference, saveRememberMePreference, saveUserDetails, loadUserDetails, clearUserDetails } from "utils/cartPersistence";

import PhoneOrEmailIcon from "components/auth/asset/PhoneOrEmailIcon";

const SignInFrm = ({
  loginFormik,
  configData,
  handleOnChange,
  passwordHandler,
  rememberMeHandleChange,
  isApiCalling,
  isLoading,
  handleSignUp,
  only,
   handleClose,
  handleClick,
}) => {
  const lanDirection = getLanguage() ? getLanguage() : "ltr";
  const theme = useTheme();
  const textColor = theme.palette.whiteContainer.main;
  const [isPhone, setIsPhone] = useState("");
  const [isOpen, setIsOpen] = useState(true);
  const [rememberMe, setRememberMe] = useState(false);

  useEffect(() => {
    const value = loginFormik.values.email_or_phone;

    const filterInput = checkInput(value);
    if (filterInput === "phone") {
      setIsPhone("phone");
    } else {
      setIsPhone("email");
    }
  }, [loginFormik.values.email_or_phone]);

  // Load remember me preference and user details from localStorage on component mount
  useEffect(() => {
    const savedRememberMe = loadRememberMePreference();
    setRememberMe(savedRememberMe);

    if (savedRememberMe) {
      const userDetails = loadUserDetails();
      if (userDetails) {
        loginFormik.setFieldValue('email_or_phone', userDetails.emailOrPhone);
        loginFormik.setFieldValue('password', userDetails.password);
      }
    }
  }, []);

  // Handle remember me checkbox change
  const handleRememberMeChange = (event) => {
    const isChecked = event.target.checked;
    setRememberMe(isChecked);

    // Save to localStorage using utility function
    saveRememberMePreference(isChecked);

    // If unchecked, clear user details
    if (!isChecked) {
      clearUserDetails();
    }

    // Call the original handler if provided
    if (rememberMeHandleChange) {
      rememberMeHandleChange(event);
    }
  };

  const onClose = () => {
    if (handleClose) {
      handleClose();
    }
    setIsOpen(false);
  };

  const handleFormSubmit = (values) => {
    // Call the original formik submit
    loginFormik.handleSubmit();

    // If remember me is checked, save user details
    if (rememberMe) {
      saveUserDetails(values.email_or_phone, values.password);
    }
  };

  if (!isOpen) return null;

  return (
  
     <Box
          sx={{
            height: "100%",
            minHeight: "700px",
            width:"750px",
            backgroundImage: `url(${SinUp.src})`,
            backgroundSize: "cover",
            backgroundPosition: "center",
            backgroundRepeat: "no-repeat",
            display: 'flex',
            justifyContent: 'flex-start',
            alignItems: "center",
            position: "relative",   
          }}
        >
           <Box
                  sx={{
                    backgroundColor: "rgba(255, 255, 255, 0)",
                    borderRadius: 2,
                    paddingLeft:"20px",
                    paddingTop:"20px",
                    paddingBottom:"20px",
                    maxWidth: "350px",
                    display: 'flex',
                     flexDirection: 'column', 
                     justifyContent: 'flex-start',
                  }}
                >
                   {/* <IconButton
                          onClick={onClose}
                          sx={{
                            zIndex: "99",
                            position: "absolute",
                            top: 6,
                            right: 6,
                            backgroundColor: (theme) => theme.palette.neutral[100],
                            borderRadius: "50%",
                            "&:hover": {
                              backgroundColor: (theme) => theme.palette.neutral[200],
                            },
                          }}
                        > */}
                          {/* <CloseIcon
                            sx={{
                              fontSize: {
                                xs: "16px",
                                sm: "18px",
                                md: "20px",
                              },
                              fontWeight: "500",
                            }}  
                          /> */}
                        {/* </IconButton> */}
                        <AuthHeader configData={configData} />

                          <Typography
                            variant="h4"
                            sx={{ fontWeight: 400, mt: 0, mb: 0, fontFamily: "Montserrat", textAlign: "center" }}
                          >
                            WELCOME BACK
                          </Typography>
                          <Typography
                            sx={{ color: "#666", mt: 1, mb: 3, fontFamily: "Montserrat", fontWeight: 400, textAlign: "center" }}
                          >
                            Please enter your details.
                          </Typography>
    
    <form noValidate onSubmit={(e) => { e.preventDefault(); handleFormSubmit(loginFormik.values); }} style={{ width: '100%' }}>
      {/* Main container with 100% width */}
      <CustomStackFullWidth
        alignItems="center"
        sx={{ maxWidth: "100%", padding: { xs: "10px", sm: "20px" } }} // Ensure the container spans 100% width
      >
        <CustomStackFullWidth
          spacing={{ xs: 2, md: 3 }}
          sx={{ position: "relative", width: "100%" }} // Ensure form content spans 100% width
        >
          {isPhone === "phone" ? (
            <CustomPhoneInputManual
              value={loginFormik.values.email_or_phone}
              onHandleChange={handleOnChange}
              initCountry={configData?.country}
              touched={loginFormik.touched.email_or_phone}
              errors={loginFormik.errors.email_or_phone}
              lanDirection={lanDirection}
              height="45px"
              autoFocus
              borderRadius="10px"
            />
          ) : (
            <CustomTextFieldWithFormik
              autoFocus={isPhone === "email" && true}
              required
              label={t("Email/Phone")}
              placeholder={t("Email/Phone")}
              touched={loginFormik.touched.email_or_phone}
              errors={loginFormik.errors.email_or_phone}
              fieldProps={loginFormik.getFieldProps("email_or_phone")}
              onChangeHandler={handleOnChange}
              value={loginFormik.values.email_or_phone}
              startIcon={
                <InputAdornment position="start">
                  <PhoneOrEmailIcon
                    sx={{
                      color:
                        loginFormik.touched.email_or_phone &&
                        !loginFormik.errors.email_or_phone
                          ? theme.palette.primary.main
                          : alpha(theme.palette.neutral[500], 0.4),
                    }}
                  />
                </InputAdornment>
              }
            />
          )}

          <CustomTextFieldWithFormik
            height="45px"
            required="true"
            type="password"
            label={t("Password")}
            placeholder={t("Enter password")}
            touched={loginFormik.touched.password}
            errors={loginFormik.errors.password}
            fieldProps={loginFormik.getFieldProps("password")}
            onChangeHandler={passwordHandler}
            value={loginFormik.values.password}
            startIcon={
              <InputAdornment position="start">
                <LockIcon
                  sx={{
                    color:
                      loginFormik.touched.password &&
                      !loginFormik.errors.password
                        ? theme.palette.primary.main
                        : alpha(theme.palette.neutral[500], 0.6),
                  }}
                />
              </InputAdornment>
            }
          />
        </CustomStackFullWidth>

        <CustomStackFullWidth mt="10px" spacing={2}>
          <CustomStackFullWidth
            justifyContent="space-between"
            alignItems="center"
            direction="row"
          >
            <FormControlLabel
              control={
                <Checkbox
                  value="remember"
                  color="primary"
                  checked={rememberMe}
                  onChange={handleRememberMeChange}
                />
              }
              label={
                <CustomTypography fontSize="14px">
                  {t("Remember me")}
                </CustomTypography>
              }
            />
            <CustomLink
              href="/forgot-password"
              sx={{ fontWeight: "400", fontSize: "14px" }}
            >
              {t("Forgot password?")}
            </CustomLink>
          </CustomStackFullWidth>

          <CustomStackFullWidth sx={{ paddingBottom: "5px" }}>
            <CustomColouredTypography
              onClick={handleClick}
              sx={{
                cursor: "pointer",
                fontWeight: "400",
                fontSize: "12px",
              }}
            >
              {t("* By login I Agree with all the")}
              <Typography
                component="span"
                color={theme.palette.primary.main}
                sx={{
                  textAlign: "center",
                  fontWeight: "400",
                  fontSize: "12px",
                }}
              >
                {t(" Terms & Conditions")}
              </Typography>
            </CustomColouredTypography>
          </CustomStackFullWidth>

          <CustomStackFullWidth spacing={2}>
            <LoadingButton
              type="submit"
              fullWidth
              variant="contained"
              loading={isLoading}
              sx={{ color: textColor, backgroundColor: "#FF6600" }}
              id="recaptcha-container"
            >
              {t("Sign In")}
            </LoadingButton>

            {only && (
              <CustomStackFullWidth alignItems="center" spacing={0.5}>
                <CustomStackFullWidth
                  direction="row"
                  alignItems="center"
                  justifyContent="center"
                  spacing={0.5}
                >
                  <CustomTypography fontSize="14px">
                    {t("Don't have an account?")}
                  </CustomTypography>
                  <span
                    onClick={handleSignUp}
                    style={{
                      color: theme.palette.primary.main,
                      textDecoration: "underline",
                      cursor: "pointer",
                    }}
                  >
                    {t("Sign Up")}
                  </span>
                </CustomStackFullWidth>
              </CustomStackFullWidth>
            )}
          </CustomStackFullWidth>
        </CustomStackFullWidth>
      </CustomStackFullWidth>
    </form>
      <CustomStackFullWidth>
        
      </CustomStackFullWidth>
      </Box>
      </Box>
  
  );
};

export default SignInFrm;
