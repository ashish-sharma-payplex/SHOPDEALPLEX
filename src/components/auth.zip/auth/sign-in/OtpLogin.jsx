import React from "react";
import LoadingButton from "@mui/lab/LoadingButton";
import { t } from "i18next";
import Typography from "@mui/material/Typography";
import {
  CustomColouredTypography,
  CustomStackFullWidth,
} from "styled-components/CustomStyles.style";
import CustomPhoneInput from "components/custom-component/CustomPhoneInput";
import { Checkbox, FormControlLabel, useTheme } from "@mui/material";
import { getLanguage } from "helper-functions/getLanguage";
import configData from "redux/slices/configData";
import { CustomTypography } from "components/landing-page/hero-section/HeroSection.style";

const OtpLogin = ({
  otpLoginFormik,
  otpHandleChange,
  global,
  isLoading,
  handleClick,
  rememberMeHandleChange,
  fireBaseId,
  configData,
}) => {
  const theme = useTheme();
  const lanDirection = getLanguage() ? getLanguage() : "ltr";

  return (
    <CustomStackFullWidth
      sx={{
        padding: "20px",
        borderRadius: "8px !Important", // Apply border radius here
        overflow: "hidden", // Ensure content doesn't overflow the rounded corners
        boxShadow: "0 4px 12px rgba(0, 0, 0, 0.1)", 
        // border:"2px solid red"
      }}
    >
      {/* Add image at the top center */}
      <CustomStackFullWidth sx={{ textAlign: "center", marginBottom: "1.5rem" }}>
        <img 
          src="/logo.png" // Path to image in the public folder
          alt="Logo" // Alt text for the image
          style={{
            maxWidth: "120px", // Set the width to a smaller size
            height: "auto", // Maintain aspect ratio
            // borderRadius: "8px", // Optional: apply the border radius to the image
            display: "block", // Center the image
            marginLeft: "auto", // Center horizontally
            marginRight: "auto", // Center horizontally
          }} 
        />
      </CustomStackFullWidth>

      {/* Centered text */}
      <CustomStackFullWidth sx={{ textAlign: "center", marginBottom: "1.5rem" }}>
        <Typography variant="h6" fontWeight="600">
          Every Essential. Just One Click Away
        </Typography>
        <Typography variant="body1" fontWeight="400" sx={{ marginTop: "0.5rem" }}>
          Log in or Sign up
        </Typography>
      </CustomStackFullWidth>

      {/* <Typography fontSize="18px" fontWeight="600" textAlign="left" mb="1rem">
        {t("Sign In")}
      </Typography> */}

      <form onSubmit={otpLoginFormik.handleSubmit} noValidate>
        <CustomStackFullWidth sx={{ gap: "14px" }}>
          <CustomPhoneInput
            value={otpLoginFormik.values.phone}
            onHandleChange={otpHandleChange}
            initCountry={configData?.country}
            touched={otpLoginFormik.touched.phone}
            errors={otpLoginFormik.errors.phone}
            rtlChange="true"
            borderRadius="10px"
            height="45px"
            lanDirection={lanDirection}
          />
          <FormControlLabel
            control={
              <Checkbox
                value="remember"
                color="primary"
                onChange={rememberMeHandleChange}
              />
            }
            label={
              <CustomTypography fontSize="14px">
                {t("Remember me")}
              </CustomTypography>
            }
          />
          <CustomStackFullWidth sx={{ paddingBottom: "5px" }}>
            <CustomColouredTypography
              onClick={handleClick}
              sx={{
                cursor: "pointer",
                fontWeight: "400",
                fontSize: "12px",
                [theme.breakpoints.down("sm")]: {
                  fontSize: "12px",
                  marginLeft: "0px",
                },
              }}
            >
              {t("* By login I Agree with all the")}
              <Typography
                component="span"
                color={theme.palette.primary.main}
                sx={{
                  textAlign: "center",
                  fontWeight: "400",
                  fontSize: "12px",
                }}
              >
                {t(" Terms & Conditions")}
              </Typography>
            </CustomColouredTypography>
          </CustomStackFullWidth>
          <LoadingButton
            type="submit"
            fullWidth
            variant="contained"
            sx={{
              fontSize: "14px",
              fontWeight: "500",
              height: "45px",
            }}
            loading={isLoading}
            id={fireBaseId}
          >
            {t("Get OTP ")}
          </LoadingButton>
        </CustomStackFullWidth>
      </form>
    </CustomStackFullWidth>
  );
};

export default OtpLogin;
