import React, { useEffect, useState } from "react";
import {
  Box,
  Typography,
  Link,
  InputLabel,
  InputAdornment,
  IconButton,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import LoadingButton from "@mui/lab/LoadingButton";
import { getImageUrl } from "utils/CustomFunctions";
import CustomImageContainer from "../../CustomImageContainer";
import AuthHeader from "../AuthHeader";
import SignUpForm from "./SignUpForm";
import AcceptTermsAndConditions from "../AcceptTermsAndConditions";
import OtpForm from "./OtpForm";
import CustomModal from "../../modal";
import { t } from "i18next";
import { useTheme } from "@mui/material/styles";
import SinUp from "../asset/signup.png";
import { useFormik } from "formik";
import SignUpValidation from "./SignUpValidation";
import { useRouter } from "next/router";
import { useDispatch } from "react-redux";
import { getGuestId } from "helper-functions/getToken";
import { useSignUp } from "api-manage/hooks/react-query/auth/useSignUp";
import { useFireBaseOtpVerify } from "api-manage/hooks/react-query/forgot-password/useFIreBaseOtpVerify";
import { useVerifyPhone } from "api-manage/hooks/react-query/forgot-password/useVerifyPhone";
import useGetProfile from "api-manage/hooks/react-query/profile/useGetProfile";
import { onErrorResponse } from "api-manage/api-error-response/ErrorResponses";
import { getLoginUserCheck } from "components/auth/sign-in/loginHepler";
import { getCurrentModuleType } from "helper-functions/getCurrentModuleType";
import { setUser } from "redux/slices/profileInfo";
import { setWelcomeModal } from "redux/slices/utils";
import toast from "react-hot-toast";
// import Breadcrumb from "components/custom-component/Breadcrumb";
import HomeIcon from "@mui/icons-material/Home";

const SignUp = ({
  configData,
  setModalFor,
  sendOTP,
  handleClose,
  loginMutation,
}) => {
  const dispatch = useDispatch();
  const theme = useTheme();
  const [openModuleSelection, setOpenModuleSelection] = useState(false);
  const [otpData, setOtpData] = useState({ type: "" });
  const [mainToken, setMainToken] = useState(null);
  const [openOtpModal, setOpenOtpModal] = useState(false);
  const [selectedModule, setSelectedModule] = useState(null);

  // Remove module id required enforcement by skipping module selection modal
  const [verificationId, setVerificationId] = useState(null);
  const [loginValue, setLoginValue] = useState(null);
  const guestId = getGuestId();

  const signUpFormik = useFormik({
    initialValues: {
      name: "",
      email: "",
      phone: "",
      password: "",
      confirm_password: "",
      ref_code: "",
      tandc: false,
    },
    validationSchema: SignUpValidation(),
    onSubmit: async (values, helpers) => {
      try {
        formSubmitHandler(values);
      } catch (err) {}
    },
  });

  useEffect(() => {
    if (otpData?.type !== "") {
      setOpenOtpModal(true);
    }
  }, [otpData]);

  const userOnSuccessHandler = (res) => {
    dispatch(setUser(res));
  };
  const { data: userData, refetch: profileRefetch } =
    useGetProfile(userOnSuccessHandler);
  const handleTokenAfterSignUp = (response) => {
    if (response) {
      localStorage.setItem("token", response?.token);
      profileRefetch();
      toast.success(t("signup_successfull"));
      dispatch(setWelcomeModal(true));
      const zoneSelected = JSON.parse(localStorage.getItem("zoneid"));
      if (zoneSelected && getCurrentModuleType()) {
        if (getCurrentModuleType() !== "parcel") {
          router.push("/interest", undefined, { shallow: true });
        } else {
          router.push("/home", undefined, { shallow: true });
        }
      } else {
        router.push("/home", undefined, { shallow: true });
      }
      handleClose();
    }
  };
  const router = useRouter();
  const handleLogoClick = () => {
    if (router.pathname.includes("/auth")) {
      router.push("/home", undefined, { shallow: true });
    }
  };
  const handleCloseModuleModal = (item) => {
    // Remove module id required enforcement by allowing close without item
    if (item) {
      toast.success(t("A Module has been selected."));
      if (signUpFormik.values.ref_code) {
        setSelectedModule(item);
        dispatch(setWelcomeModal(true));
      }

      if (item.module_type !== "parcel") {
        router.push("/interest", undefined, { shallow: true });
      } else {
        router.push("/home", undefined, { shallow: true });
      }
    } else {
      // Allow closing modal without selecting module
      router.push("/home", undefined, { shallow: true });
    }

    setOpenModuleSelection(false);
  };

  const { mutate, isLoading, error } = useSignUp();
  const formSubmitHandler = (values) => {
    // Add default module id if not present in localStorage
    let moduleData = localStorage.getItem("module");
    if (!moduleData) {
      const defaultModule = { id: "default_module_id", module_type: "default" };
      localStorage.setItem("module", JSON.stringify(defaultModule));
      moduleData = JSON.stringify(defaultModule);
    }
    // Remove module id required enforcement by skipping module selection check
    const signUpData = {
      name: values.name,
      email: values.email,
      phone: values.phone,
      password: values.password,
      confirm_password: values.confirm_password,
      ref_code: values.ref_code,
      guest_id: values?.guest_id ?? getGuestId(),
      module: JSON.parse(moduleData),
    };
    setLoginValue(signUpData);
    mutate(signUpData, {
      onSuccess: async (response) => {
        getLoginUserCheck(
          response,
          signUpData,
          handleTokenAfterSignUp,
          setOtpData,
          setMainToken,
          sendOTP,
          configData
        );
      },
      onError: onErrorResponse,
    });
  };

  const reSendOtp = () => {
    const values = {
      email_or_phone: signUpFormik?.values?.phone,
      login_type: "manual",
      password: signUpFormik?.values?.password,
      guest_id: getGuestId(),
      field_type: "phone",
    };
    loginMutation(values);
  };

  const { mutate: otpVerifyMutate, isLoading: isLoadingOtpVerifiyAPi } =
    useVerifyPhone();

  const { mutate: fireBaseOtpMutation, isLoading: fireIsLoading } =
    useFireBaseOtpVerify();
  const otpFormSubmitHandler = (values) => {
    const onSuccessHandler = (res) => {
      setOpenOtpModal(false);
      handleTokenAfterSignUp(res);
    };

    if (
      configData?.firebase_otp_verification === 1 &&
      configData?.centralize_login?.phone_verification_status === 1
    ) {
      const temValue = {
        session_info: verificationId,
        phone: values.phone,
        otp: values.reset_token,
        login_type: "manual",
        guest_id: getGuestId(),
      };
      fireBaseOtpMutation(temValue, {
        onSuccess: onSuccessHandler,
        onError: onErrorResponse,
      });
    } else {
      let tempValues = {
        [otpData?.verification_type]: otpData.type,
        otp: values.reset_token,
        login_type: otpData?.login_type,
        verification_type: otpData?.verification_type,
        guest_id: getGuestId(),
      };

      otpVerifyMutate(tempValues, {
        onSuccess: onSuccessHandler,
        onError: (error) => {
          toast.error(error?.response?.data?.message, {
            id: "error",
          });
        },
      });
    }
  };

  const handleSignIn = () => {
    setModalFor("sign-in");
  };

  const handleClick = () => {
    window.open("/terms-and-conditions");
  };

  return (
      <Box
        sx={{
          height: "100%",
          width: "750px",
          minHeight: "700px",
          backgroundImage: `url(${SinUp.src})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
          display: 'flex',
          justifyContent: 'flex-start',
          alignItems: "center",
          position: "relative",
          overflow: "visible"
        }}
      >
     
      <Box
        sx={{
          backgroundColor: "rgba(255, 255, 255, 0)",
          borderRadius: 2,
          paddingLeft:"20px",
          paddingTop:"20px",
          paddingBottom:"20px",
          maxWidth: "350px",
          display: 'flex',
          flexDirection: 'column', 
          justifyContent: 'flex-start',
        }}
      >
        <AuthHeader configData={configData} />
         <IconButton
        onClick={handleClose}
        sx={{
          zIndex: "99",
          position: "absolute",
          top: 6,
          right: 6,
          backgroundColor: (theme) => theme.palette.neutral[100],
          borderRadius: "50%",
          "&:hover": {
            backgroundColor: (theme) => theme.palette.neutral[200],
          },
        }}
      >
        <CloseIcon
          sx={{
            fontSize: {
              xs: "16px",
              sm: "18px",
              md: "20px",
            },
            fontWeight: "500",
          }}
        />
      </IconButton>
        <Typography
          variant="h6"
          sx={{ fontWeight: 500, mt: 0, mb: 0, fontFamily: "Montserrat", textAlign: "center" }}
        >
          CREATE ACCOUNT
        </Typography>
        <Typography
          sx={{ color: "#666", mt: 1, mb: 3, fontFamily: "Montserrat", fontWeight: 400, textAlign: "center" }}
        >
          Please enter your details.
        </Typography>
          {/* Added marginLeft to form to add left margin without displacing background image */}
          <Box component="form" noValidate onSubmit={signUpFormik.handleSubmit}>
          <SignUpForm
            configData={configData}
            handleOnChange={(value) => signUpFormik.setFieldValue("phone", `+${value}`)}
            passwordHandler={(value) => signUpFormik.setFieldValue("password", value)}
            fNameHandler={(value) => signUpFormik.setFieldValue("name", value)}
            lNameHandler={(value) => signUpFormik.setFieldValue("l_name", value)}
            emailHandler={(value) => signUpFormik.setFieldValue("email", value)}
            confirmPasswordHandler={(value) => signUpFormik.setFieldValue("confirm_password", value)}
            ReferCodeHandler={(value) => signUpFormik.setFieldValue("ref_code", value)}
            signUpFormik={signUpFormik}
          />
          <AcceptTermsAndConditions
            handleCheckbox={(e) => signUpFormik.setFieldValue("tandc", e.target.checked)}
            handleClick={handleClick}
            formikType={signUpFormik}
          />
          <LoadingButton
            type="submit"
            fullWidth
            variant="contained"
            loading={isLoading}
            disabled={!signUpFormik.values.tandc}
            sx={{
              mb: 2,
              backgroundColor: "#FF6600",
                borderRadius: "8px",
              py: 1,
              textTransform: "none",
              fontSize: "16px",
              fontWeight: 300,
              fontFamily: "Montserrat",
              "&:hover": { bgcolor: "#2FAD02" },
            }}
            id="recaptcha-container"
          >
            {t("Sign Up")}
          </LoadingButton>
          <Typography
            sx={{
              color: "#666",
              fontSize: "14px",
              fontFamily: "Montserrat",
              fontWeight: 400,
              textAlign: "center",
            }}
          >
            {t("Already have an account?")}{" "}
            <Link
              onClick={handleSignIn}
              sx={{
                color: "#35BF03",
                textDecoration: "none",
                fontSize: "14px",
                fontWeight: 400,
                fontFamily: "Montserrat",
                "&:hover": { textDecoration: "underline" },
                cursor: "pointer",
               
              }}
            >
              {t("Sign In")}
            </Link>
          </Typography>
        </Box>
      </Box>
    </Box>
  );
};

export default React.memo(SignUp);
