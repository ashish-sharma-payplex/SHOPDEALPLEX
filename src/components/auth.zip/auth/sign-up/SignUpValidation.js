import * as Yup from "yup";
import { useTranslation } from "react-i18next";

const SignUpValidation = () => {
  const { t } = useTranslation();

  return Yup.object({
    name: Yup.string()
      .required(t("First name is required"))
      .min(2, t("Username must be at least 2 characters"))
      .max(50, t("Username must be less than 50 characters"))
      .matches(
        /^[a-zA-Z0-9_]+$/,
        t("Username can only contain letters, numbers, and underscores")
      ),
    email: Yup.string()
      .email(t("Must be a valid email"))
      .max(255)
      .required(t("Email is required"))
      .matches(
        /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
        t("Please enter a valid email address")
      ),
    phone: Yup.string()
      .required(t("Please give a phone number"))
      .min(10, t("Phone number must be at least 10 digits"))
      .matches(
        /^[0-9+\-\s()]+$/,
        t("Phone number can only contain numbers, spaces, hyphens, parentheses, and +")
      ),
    password: Yup.string()
      .required(t("Password is required"))
      .min(6, t("Password is too short - should be 6 chars minimum."))
      .matches(
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/,
        t("Password must contain at least one uppercase letter, one lowercase letter, and one number")
      ),
    confirm_password: Yup.string()
      .required(t("Confirm Password"))
      .oneOf([Yup.ref("password"), null], t("Passwords must match")),
    //tandc: Yup.boolean().oneOf([true], "Message"),
  });
};

export default SignUpValidation;
