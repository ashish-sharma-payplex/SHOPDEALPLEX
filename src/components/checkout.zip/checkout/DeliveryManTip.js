import React, { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import CloseIcon from "@mui/icons-material/Close";
import FavoriteIcon from "@mui/icons-material/Favorite";
import CurrencyRupeeIcon from "@mui/icons-material/CurrencyRupee";
import EmojiEmotionsIcon from "@mui/icons-material/EmojiEmotions";
import {
  CustomBoxForTips,
  CustomStackFullWidth,
  CustomTextField,
} from "../../styled-components/CustomStyles.style";
import { Grid, Typography, Tooltip, Fade, Paper, Box } from "@mui/material";
import { Stack } from "@mui/system";
import { CouponTitle, DeliveryCaption, RoundButton } from "./CheckOut.style";
import { useTheme } from "@emotion/react";
import { toast } from 'react-hot-toast';
import CheckIcon from "@mui/icons-material/Check";  // Add this import
import { getAmountWithSign } from "helper-functions/CardHelpers";
const DeliveryManTip = ({
  deliveryTip,
  setDeliveryTip,
  isSmall,
  tripsData,
}) => {
  const [show, setShow] = useState(false);
  const theme = useTheme();
  const [fieldValue, setFieldValue] = useState(deliveryTip);
  const [isCustom, setIsCustom] = useState(false);
  const deliveryTips = [20, 30, 50];
  const { t } = useTranslation();

  let debounceTimeout;

  const debouncedSetInputValue = (value) => {
    if (debounceTimeout) {
      clearTimeout(debounceTimeout); // Clear the previous timeout
    }

    debounceTimeout = setTimeout(() => {
      setDeliveryTip(value); // Execute the function after 300ms
    }, 300);
  };
const handleOnChange = (e) => {
  let value = e.target.value;

  // Check if the value is a valid number and is not greater than 100
  if (value > -1 && value <= 100) {
    setFieldValue(value);
    debouncedSetInputValue(value);
    setIsCustom(true);
  } else if (value > 100) {
    // Display a toast error message if the value exceeds 100
    toast.error(t("Max tip amount is ₹100")); 

    setFieldValue(100);  // Automatically set to 100 if the value exceeds 100
    debouncedSetInputValue(100);
    setIsCustom(true);  // Still consider it as a custom value
  } else {
    setIsCustom(false);
  }
};


  const handleClickOnTips = (tip) => {
    setFieldValue(tip);
    setIsCustom(false);
  };
  useEffect(() => {
    debouncedSetInputValue(fieldValue);
  }, [fieldValue]);

  const handleShow = () => {
    setShow(true);
  };
  const handleClose = () => {
    setShow(false);
  };
  return (
     <CustomStackFullWidth>
  <Grid container rowGap="14px" spacing={1}>
    <Grid item xs={12} md={12}>
      <Box sx={{ display: 'flex', flexDirection:'column', alignItems: 'left', gap: 0.5, mb: 0.5 }}>
        {/* <EmojiEmotionsIcon sx={{ color: "#FF6600", fontSize: '24px' }} /> */}
    <DeliveryCaption sx={{ fontSize: '16px', fontWeight: 'bold' }}>
      {t("Tip your delivery partner")}
    </DeliveryCaption>

    <Typography sx={{ fontSize: '12px', fontWeight: 'normal', color: theme.palette.text.secondary, mt: 1 }}>
      {t("Every penny of your kind tip will go straight to your delivery partner. Thank you!")}
    </Typography>

      </Box>
      {/* {deliveryTip > 0 && (
        <Fade in={deliveryTip > 0}>
          <Paper
            elevation={2}
            sx={{
              p: 2,
              background: `linear-gradient(135deg, ${theme.palette.primary.light}20, ${theme.palette.secondary.light}20)`,
              border: `1px solid ${theme.palette.primary.main}30`,
              borderRadius: 2,
            }}
          >
            <Typography variant="body2" color="text.secondary">
              {t("Selected tip")}: <strong>{getAmountWithSign(deliveryTip)}</strong>
            </Typography>
          </Paper>
        </Fade>
      )} */}
    </Grid>
    {!show && (
      <Grid item xs={12}>
        <CustomStackFullWidth
          direction="row"
          alignItems="center"
          gap="8px"
          flexWrap="wrap"
        >
          {deliveryTips.map((item, index) => {
            const isActive = item === deliveryTip;
            const isMostTipped = tripsData?.most_tips_amount === item;
            return (
              <Stack key={index} alignItems="flex-start">
                <Tooltip title={index === 0 ? t("Skip tipping") : t("Tip the delivery person")}>
                  <CustomBoxForTips
                    onClick={() => handleClickOnTips(item)}
                    active={isActive}
                   sx={{
                        background: isActive ? '#28a745' : '#FFFFFF',  // Active state becomes green, inactive is white
                        border: isActive ? '1px solid #28a745' : '1px solid #66666633', // Border is green when active, light grey when inactive
                        boxShadow: isActive 
                          ? '0 4px 12px rgba(40, 167, 69, 0.3)'  // Green shadow when active
                          : '0 2px 8px rgba(0, 0, 0, 0.1)',  // Light shadow when inactive
                        transition: 'all 0.3s ease',
                        '&:hover': {
                          transform: 'translateY(-2px)',
                          boxShadow: isActive 
                            ? '0 6px 16px rgba(40, 167, 69, 0.15)'  // Green shadow on hover when active
                            : '0 6px 16px rgba(0, 0, 0, 0.15)',  // Light shadow on hover when inactive
                          borderColor: theme.palette.primary.main,  // Border color on hover (primary color)
                        },
                        position: 'relative',
                        overflow: 'hidden',
                        width: '50px',  // Ensure buttons are compact
                        height: '30px',
                        padding: '2px 2px',  // Reduce padding to make buttons smaller  
                      }}
                  >
                  <Stack direction="row" alignItems="center" spacing={0.5}>
                    {index === 0 ? (
                      <img
                        src="/tip1.png"  // Path to the image for ₹20
                        alt="₹20 Tip Icon"
                        style={{
                          width: '12px',
                          height: '12px',
                          
                        }}
                      />
                    ) : index === 1 ? (
                      <img
                        src="/tip2.png"  // Path to the image for ₹30
                        alt="₹30 Tip Icon"
                        style={{
                          width: '12px',
                          height: '12px',
                         
                        }}
                      />
                    ) : index === 2 ? (
                      <img
                        src="tip3.png"  // Path to the image for ₹50
                        alt="₹50 Tip Icon"
                        style={{
                          width: '12px',
                          height: '12px',
                         
                        }}
                      />
                    ) : (
                      <img
                        src="/customtip.png"  // Default image if none of the conditions are met
                        alt="Default Tip Icon"
                        style={{
                          width: '12px',
                          height: '12px',
                         
                        }}
                      />
                    )}

                    <Typography
                      fontSize={isActive ? "14px" : "12px"}
                      textTransform="capitalize"
                      fontWeight="600"
                      color={isActive ? theme.palette.whiteContainer.main : theme.palette.primary.main}
                    >
                      {getAmountWithSign(item)}
                    </Typography>
                  </Stack>

                    {isMostTipped && !isSmall && (
                      <Stack
                        position="absolute"
                        bottom="0px"
                        alignItems="center"
                        width="100%"
                        sx={{
                          background: `linear-gradient(180deg, transparent, #FF6600})`,
                          borderRadius: '0 0 8px 8px',
                        }}
                      >
                        <Typography
                          color={theme.palette.whiteContainer.main}
                          fontSize="9px"
                          fontWeight="bold"
                          sx={{ py: 0.5 }}
                        >
                          {t("Most Tipped")}
                        </Typography>
                      </Stack>
                    )}
                  </CustomBoxForTips>
                </Tooltip>
                {isMostTipped && isSmall && (
                  <Typography
                    color={theme.palette.primary.main}
                    fontSize="10px"
                    fontWeight="bold"
                    sx={{ mt: 0.5 }}
                  >
                    {t("Most Tipped")}
                  </Typography>
                )}
              </Stack>
            );
          })}
          <Tooltip title={t("Enter custom tip amount")}>
    <CustomBoxForTips
      onClick={handleShow}
      active={isCustom}
      sx={{
        background: isCustom ? '#28a745' : '#FFFFFF',  // Green when active, white when inactive
        border: isCustom ? '1px solid #28a745' : '1px solid #66666633',  // Green border when active, light grey border when inactive
        boxShadow: isCustom 
          ? '0 4px 12px rgba(40, 167, 69, 0.3)'  // Green shadow when active
          : '0 2px 8px rgba(0, 0, 0, 0.1)',  // Light shadow when inactive
        transition: 'all 0.3s ease',
        '&:hover': {
          transform: 'translateY(-2px)',
          boxShadow: isCustom 
            ? '0 6px 16px rgba(40, 167, 69, 0.15)'  // Green shadow on hover when active
            : '0 6px 16px rgba(0, 0, 0, 0.15)',  // Light shadow on hover when inactive
          borderColor: theme.palette.primary.main,  // Border color on hover (primary color)
        },
        width: '70px', // Button width
        height: '30px', // Button height
        padding: '2px 2px', // Reduced padding for compact style
      }}
    >
      <Stack direction="row" alignItems="center" spacing={0.5}>
          <img
            src="/customtip.png"  // Path to your custom symbol image
            alt="Custom Symbol"
            style={{
              width: '14px',   // Adjust the width of the symbol as needed
              height: '14px',  // Adjust the height of the symbol as needed
              color: isCustom ? theme.palette.whiteContainer.main : theme.palette.primary.main,  // Apply color if needed
            }}
          />
        <Typography
          color={isCustom ? theme.palette.whiteContainer.main : theme.palette.primary.main}
          fontSize="12px"
          fontWeight="600"
        >
          {t("Custom")}
        </Typography>
      </Stack>
    </CustomBoxForTips>

          </Tooltip>
        </CustomStackFullWidth>
      </Grid>
    )}
    {show && (
      <Fade in={show}>
        <Stack
          width="100%"
          direction="row"
          spacing={2}
          sx={{
            p: 2,
            background: `linear-gradient(135deg, ${theme.palette.background.paper}, ${theme.palette.grey[50]})`,
            borderRadius: 2,
            border: `1px solid ${theme.palette.grey[300]}`,
          }}
        >
          <CustomTextField
            type="number"
            label={t("Enter tip amount")}
            autoFocus={true}
            value={fieldValue}
            onChange={(e) => handleOnChange(e)}
            InputProps={{
              inputProps: { min: 0 },
              startAdornment: <CurrencyRupeeIcon sx={{ color: theme.palette.primary.main, mr: 1 }} />,
            }}
            sx={{
              '& .MuiOutlinedInput-root': {
                '&:hover fieldset': {
                  borderColor: theme.palette.primary.main,
                },
                '&.Mui-focused fieldset': {
                  borderColor: theme.palette.primary.main,
                },
              },
            }}
            onKeyPress={(event) => {
              if (event?.key === "-" || event?.key === "+") {
                event.preventDefault();
              }
            }}
          />
          <Tooltip title={t("Close custom tip input")}>
            <RoundButton
              onClick={handleClose}
              minWidth="50px"
              padding="9px 16px"
              sx={{
                background: `linear-gradient(135deg, ${theme.palette.grey[400]}, ${theme.palette.grey[500]})`,
                '&:hover': {
                  background: `linear-gradient(135deg, ${theme.palette.grey[500]}, ${theme.palette.grey[600]})`,
                  transform: 'scale(1.05)',
                },
                transition: 'all 0.2s ease',
              }}
            >
              <CloseIcon sx={{ width: "15px", height: "20px" }} />
            </RoundButton>
          </Tooltip>
        </Stack>
      </Fade>
    )}
  </Grid>
</CustomStackFullWidth>

  );
};

export default DeliveryManTip;
