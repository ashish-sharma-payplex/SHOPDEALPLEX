import React, { useState } from "react";
import {
  alpha,
  Button,
  FormControl,
  FormControlLabel,
  Grid,
  Radio,
  RadioGroup,
  Stack,
  styled,
  Tooltip,
  Typography,
} from "@mui/material";

import { t } from "i18next";

import { CustomStackFullWidth } from "../../../styled-components/CustomStyles.style";
import CustomImageContainer from "../../CustomImageContainer";
import PaymentMethodCard from "../PaymentMethodCard";
import InfoIcon from "@mui/icons-material/Info";
import { useTheme } from "@emotion/react";
import { useDispatch, useSelector } from "react-redux";
import { DeliveryCaption } from "../CheckOut.style";
import { setOfflineMethod } from "../../../redux/slices/offlinePaymentData";
import { getToken } from "../../../helper-functions/getToken";
import wallet from "../assets/wallet.png";
import money from "../assets/money.png";
import OfflinePaymentIcon from "../assets/OfflinePaymentIcon";
import RadioButtonUncheckedIcon from "@mui/icons-material/RadioButtonUnchecked";
import RadioButtonCheckedIcon from "@mui/icons-material/RadioButtonChecked";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";  // Optional check icon if needed


export const PayButton = styled(Button)(({ theme, value, paymentMethod }) => ({
  padding: "18px 18px",
  gap: "5px",
  // border: "1px solid",
  // borderColor: value === paymentMethod ? "green" : alpha(theme.palette.neutral[400], 0.4), 
  color: theme.palette.neutral[1000], // Keep text color black
  background: "none", // No background color change when selected
  "&:hover": {
    background: "none", // No background color change on hover
  },
}));


const OfflineButton = styled(Button)(({ theme, value, paymentMethod }) => ({
  padding: "15px 15px",
  // border: "1px solid",
  // borderColor: value?.id === paymentMethod?.id ? "green" : "#E4F4FF", // Green border when selected
  filter: `drop-shadow(-1px 1px 0px ${alpha(theme.palette.info.light, 0.2)})`,
  gap: "5px",
  color: theme.palette.neutral[1000], // Keep text color black
  background: "none", // No background color when selected
  "&:hover": {
    color: theme.palette.whiteContainer.main,
    background: "none", // No background color change on hover
  },
}));


const OtherModulePayment = (props) => {
  const {
    paymentMethod,
    setPaymentMethod,
    paidBy,
    orderPlace,
    isLoading,
    zoneData,
    forprescription,
    configData,
    orderType,
    parcel,
    setOpenModel,
    usePartialPayment,

    offlinePaymentOptions,
    setPaymentMethodImage,
    isZoneDigital,
  } = props;
  console.log("_________________________")
  console.log(configData)


  const theme = useTheme();
  const dispatch = useDispatch();
  const token = getToken();
  const borderColor = theme.palette.neutral[400];
  const [openOfflineOptions, setOpenOfflineOptions] = useState(false);

  const { offlineMethod } = useSelector((state) => state.offlinePayment);
  const [isCheckedOffline, setIsCheckedOffline] = useState(
    offlineMethod !== ""
  );

  const handleClickOffline = () => {
    setOpenOfflineOptions(!openOfflineOptions);
  };
  const handleClick = (item) => {
    setPaymentMethod(item);
    dispatch(setOfflineMethod(""));  // Reset any offline method if switching
    setIsCheckedOffline(false);
    setOpenModel(false);  // Close the modal as soon as a method is selected
  };

  const handleClickOfflineItem = (item) => {
    dispatch(setOfflineMethod(item));
    setIsCheckedOffline(true);
    setPaymentMethod(`offline_payment`);
    setOpenModel(false);  // Close the modal as soon as an offline method is selected
  };

  const handleSubmit = () => {
    setOpenModel(false);
  };
  const handleCancel = () => {
    setOpenModel(false);
  };


  return (
    <CustomStackFullWidth spacing={1.5} >
      <CustomStackFullWidth gap="20px" sx={{border:"1px solid #e0e0e0",borderRadius:"10px"}} >
        {/* <DeliveryCaption>{t("Payment Method")}</DeliveryCaption> */}
        <CustomStackFullWidth spacing={1}  >
          <CustomStackFullWidth
            direction="column"
            spacing={{ xs: 0, md: 1.7 }}
            sx={{ flexWrap: "wrap", gap: "5px"}}
          >
            {/* cash on delivery starts */}
            <Stack sx={{ borderBottom: "1px solid #e0e0e0", paddingBottom: "6px" }} >
              {usePartialPayment
                ? ((isZoneDigital?.cash_on_delivery &&
                  configData?.cash_on_delivery &&
                  configData?.partial_payment_method === "both") ||
                  configData?.partial_payment_method === "cod") && (
                  <PayButton
                    value="cash_on_delivery"
                    paymentMethod={paymentMethod}
                    onClick={() => handleClick("cash_on_delivery")}
                    sx={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      padding: '8px 16px',
                      // borderRadius: '5px',
                      // border: '1px solid #E0E0E0',
                      backgroundColor: "white", // Keep the background white
                    }}
                  >
                    {/* Left side: SVG Image + Title and Subtitle (left-aligned) */}
                    <Stack direction="row" alignItems="center" spacing={2}>
                      {/* Left SVG Image */}
                      <CustomImageContainer
                        src="/public/money.svg"  // Replace with the actual SVG path
                        width="20px"
                        height="20px"
                        alt="cod"
                      />
                      {/* Title and Subtitle */}
                      <Stack spacing={0.3} sx={{ textAlign: 'left' }}>
                        <Typography fontSize="14px" fontWeight={500}>
                          {t("Cash On Delivery")}
                        </Typography>
                        <Typography fontSize="12px" color="text.secondary">
                          {t("Pay cash at the time of delivery.")}
                        </Typography>
                      </Stack>
                    </Stack>

                    {/* Right side: Radio Button */}
                    {paymentMethod === "cash_on_delivery" ? (
                      <RadioButtonCheckedIcon sx={{ color: 'green', fontSize: '24px', borderColor: 'green', borderRadius: '50%' }} />
                    ) : (
                      <RadioButtonUncheckedIcon sx={{ color: '#c7c7c7', fontSize: '24px' }} />
                    )}
                  </PayButton>
                )
                : isZoneDigital?.cash_on_delivery &&
                configData?.cash_on_delivery && (
                  <PayButton
                    value="cash_on_delivery"
                    paymentMethod={paymentMethod}
                    onClick={() => handleClick("cash_on_delivery")}
                    sx={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      padding: '8px 16px',
                      // borderRadius: '5px',
                      // border: '1px solid #E0E0E0',
                      backgroundColor: "white", // Keep the background white
                    }}
                  >
                    {/* Left side: SVG Image + Title and Subtitle (left-aligned) */}
                    <Stack direction="row" alignItems="center" spacing={2}>
                      {/* Left SVG Image */}
                      <CustomImageContainer
                        src="/cod.svg"  // Replace with the actual SVG path
                        width="25px"
                        height="25px"
                        alt="cod"
                      />
                      {/* Title and Subtitle */}
                      <Stack spacing={0.3} sx={{ textAlign: 'left' }}>
                        <Typography fontSize="14px" fontWeight={500}>
                          {t("Cash On Delivery")}
                        </Typography>
                        <Typography fontSize="12px" color="text.secondary">
                          {t("Pay cash at the time of delivery.")}
                        </Typography>
                      </Stack>
                    </Stack>

                    {/* Right side: Radio Button */}
                    {paymentMethod === "cash_on_delivery" ? (
                      <RadioButtonCheckedIcon sx={{ color: 'green', fontSize: '24px', borderColor: 'green', borderRadius: '50%' }} />
                    ) : (
                      <RadioButtonUncheckedIcon sx={{ color: '#c7c7c7', fontSize: '24px' }} />
                    )}
                  </PayButton>
                )}
            </Stack>
            {/* Cash on delivery end */}

            {/* Wallet starts */}
            <Stack sx={{ borderBottom: "1px solid #e0e0e0", paddingBottom: "6px" }} >
              {configData?.customer_wallet_status === 1 &&
                forprescription !== "true" &&
                token && (
                  <PayButton
                    onClick={() => handleClick("wallet")}
                    value="wallet"
                    paymentMethod={paymentMethod}
                    disabled={usePartialPayment}
                    sx={{
                      display: 'flex',
                      justifyContent: 'space-between',  // Same as Code 1
                      alignItems: 'center',
                      padding: '8px 16px',
                      // borderRadius: '5px',
                      // border: '1px solid #E0E0E0',
                      backgroundColor: "white",  // Maintain consistent white background
                    }}
                  >
                    {/* Left side: Image + Title and Subtitle (left-aligned) */}
                    <Stack direction="row" alignItems="center" spacing={2}>
                      {/* Wallet Icon */}
                      <CustomImageContainer
                        src="/paywallet.svg" // Replace with the actual path to your wallet icon
                        width="22px"
                        height="22px"
                        alt="wallet"
                      />
                      {/* Title and Subtitle */}
                      <Stack spacing={0.3} sx={{ textAlign: 'left' }}>
                        <Typography fontSize="14px" fontWeight={500}>
                          {t("Pay via Wallet")}
                        </Typography>
                        <Typography fontSize="12px" color="text.secondary">
                          {t("Use your wallet balance to pay.")} {/* Add subtitle if needed */}
                        </Typography>
                      </Stack>
                    </Stack>

                    {/* Right side: Radio Button */}
                    {paymentMethod === "wallet" ? (
                      <RadioButtonCheckedIcon sx={{ color: 'green', fontSize: '24px', borderColor: 'green', borderRadius: '50%' }} />
                    ) : (
                      <RadioButtonUncheckedIcon sx={{ color: '#c7c7c7', fontSize: '24px' }} />
                    )}
                  </PayButton>
                )}
            </Stack>
            {/* Wallet ends */}
          </CustomStackFullWidth>

          {/* Digital Payment starts  */}
          <Stack sx={{ mt: "18px !important" }}> {/* Increased margin to test the effect */}
            {isZoneDigital?.digital_payment &&
              paidBy !== "receiver" &&
              forprescription !== "true" &&
              configData?.digital_payment_info?.digital_payment &&
              (configData?.partial_payment_method === "digital_payment" ||
                configData?.partial_payment_method === "both" ||
                configData?.partial_payment_method === null) && (
                <CustomStackFullWidth spacing={2.4} sx={{ width: '100%' }}>
                  {/* Payment Methods List */}
                  <CustomStackFullWidth sx={{ width: '100%' }}>
                    <Grid container sx={{ width: '100%' }}>
                      {configData?.active_payment_method_list?.map((item, index) => {
                        return (
                          <Grid item xs={12} key={index}>
                            <PayButton
                              value={item?.gateway}
                              paymentMethod={paymentMethod}
                              onClick={() => handleClick(item?.gateway)}
                              sx={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                padding: '8px 16px',
                                // borderRadius: '5px',
                                // border: '1px solid #E0E0E0',
                                backgroundColor: 'white',
                                width: '100%'  // Full width for PayButton
                              }}
                            >
                              {/* Left side: Image + Title and Subtitle (left-aligned) */}
                              <Stack direction="row" alignItems="center" spacing={2}>
                                {/* Payment Method Icon */}
                                <CustomImageContainer
                                  src="/paywallet.svg"  // Use the actual image URL
                                  width="20px"
                                  height="20px"
                                  alt={item?.gateway_title}
                                />
                                {/* Title and Subtitle */}
                                <Stack spacing={0.3} sx={{ textAlign: 'left' }}>
                                  <Typography fontSize="14px" fontWeight={500}>
                                    {item?.gateway_title}
                                  </Typography>
                                  <Typography fontSize="12px" color="text.secondary">
                                    {item?.gateway_description || t("Pay using this method")}
                                  </Typography>
                                </Stack>
                              </Stack>

                              {/* Right side: Radio Button */}
                              {paymentMethod === item?.gateway ? (
                                <RadioButtonCheckedIcon sx={{ color: 'green', fontSize: '24px', borderColor: 'green', borderRadius: '50%' }} />
                              ) : (
                                <RadioButtonUncheckedIcon sx={{ color: '#c7c7c7', fontSize: '24px' }} />
                              )}
                            </PayButton>
                          </Grid>
                        );
                      })}
                    </Grid>
                  </CustomStackFullWidth>
                </CustomStackFullWidth>
              )}
          </Stack>
          {/* Digital Payment ends  */}

        </CustomStackFullWidth>
        <Stack onClick={handleClickOffline} sx={{ cursor: "pointer" }}>
          {configData?.offline_payment_status === 1 &&
            isZoneDigital?.offline_payment &&
            forprescription !== "true" &&
            typeof offlinePaymentOptions !== "undefined" &&
            Object?.keys(offlinePaymentOptions)?.length !== 0 ? (
            <Stack
              padding="10px 10px 10px 25px"
              borderRadius="10px"
              backgroundColor={alpha(theme.palette.primary.main, 0.1)}
            >
              <CustomStackFullWidth gap="15px">
                <CustomStackFullWidth
                  flexDirection="row"
                  justifyContent="space-between"
                >
                  <FormControl
                    sx={{
                      marginRight: { xs: "0px" },
                      marginLeft: { xs: "5px" },
                    }}
                  >
                    <RadioGroup
                      aria-labelledby="demo-radio-buttons-group-label"
                      name="radio-buttons-group"
                      fontWeight="600"
                    >
                      <FormControlLabel
                        value={t("Pay Offline")}
                        control={
                          <Radio
                            sx={{ padding: { xs: "2px", md: "10px" } }}
                            checked={isCheckedOffline}
                            onClick={handleClickOffline}
                          />
                        }
                        label={
                          <Stack
                            flexDirection="row"
                            gap="16px"
                            paddingLeft={{ xs: "5px", sm: "5px", md: "10px" }}
                          >
                            <OfflinePaymentIcon />
                            <Typography
                              fontSize="12px"
                              fontWeight="500"
                            // paddingLeft="10px"
                            >
                              {t("Pay Offline")}
                              <Typography
                                component="span"
                                fontSize="10px"
                                ml="5px"
                              >
                                ( {t("Select option from below")} )
                              </Typography>
                            </Typography>
                          </Stack>
                        }
                      />
                    </RadioGroup>
                  </FormControl>
                  <Tooltip
                    placement="left"
                    title={t(
                      "Offline Payment! Now, with just a click of a button, you can make secure transactions. It's simple, convenient, and reliable."
                    )}
                  >
                    <InfoIcon
                      fontSize="16px"
                      sx={{ color: theme.palette.primary.main }}
                    />
                  </Tooltip>
                </CustomStackFullWidth>
                {openOfflineOptions && (
                  <CustomStackFullWidth>
                    <CustomStackFullWidth flexDirection="row" gap="20px">
                      {offlinePaymentOptions?.map((item, index) => {
                        return (
                          <OfflineButton
                            key={index}
                            value={item}
                            paymentMethod={offlineMethod}
                            onClick={() => handleClickOfflineItem(item)}
                          >
                            <Typography fontSize="12px">
                              {item.method_name}
                            </Typography>
                          </OfflineButton>
                        );
                      })}
                    </CustomStackFullWidth>
                  </CustomStackFullWidth>
                )}
              </CustomStackFullWidth>
            </Stack>
          ) : null}
        </Stack>
        {/* <Stack
          direction="row"
          width="100%"
          spacing={1}
          justifyContent="flex-end"
          gap="10px"
        >
          <Button
            onClick={() => handleCancel()}
            style={{
              border: `1px solid ${borderColor}`,
              borderRadius: "5px",
              color: borderColor,
              padding: "8px 16px",
            }}
          >
            {t("Close")}
          </Button>
          <Button
            variant="contained"
            onClick={() => handleSubmit()}
            disabled={paymentMethod || isCheckedOffline ? false : true}
            style={{
              borderRadius: "5px",
              padding: "8px 22px",
            }}
          >
            {t("Submit")}
          </Button>
        </Stack> */}

      </CustomStackFullWidth>
    </CustomStackFullWidth>
  );
};

export default OtherModulePayment;
