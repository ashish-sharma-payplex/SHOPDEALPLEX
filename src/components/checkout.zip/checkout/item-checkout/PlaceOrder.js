import { Checkbox, FormControlLabel, FormGroup } from "@mui/material";
import { useState } from "react";
import { useTranslation } from "react-i18next";
import { CustomStackFullWidth } from "../../../styled-components/CustomStyles.style";
import { useTheme } from "@emotion/react";
import LoadingButton from "@mui/lab/LoadingButton";
import Link from "next/link";
import { useRouter } from "next/router";
import { useDispatch, useSelector } from "react-redux";
import { setOfflineInfoStep } from "../../../redux/slices/offlinePaymentData";
import { CustomTypography } from "../../landing-page/hero-section/HeroSection.style";

const PlaceOrder = (props) => {
  const {
    placeOrder,
    orderLoading,
    zoneData,
    isStoreOpenOrNot,
    storeData,
    isSchedules,
    page,
    storeCloseToast,
    isLoading,
  } = props;

  const [disabled, setDisabled] = useState(true);

  const { offlineInfoStep } = useSelector((state) => state.offlinePayment);
  const { t } = useTranslation();
  const theme = useTheme();
  const router = useRouter();
  const dispatch = useDispatch();
  const [checked, setChecked] = useState(false);

  const handleChange = (e) => {
    console.log("Checkbox state changed:", e.target.checked); // Debug log
    setChecked(e.target.checked);
  };

  const handleOffline = (e) => {
    console.log("Handle offline clicked. Store active:", storeData?.active); // Debug log
    if (storeData?.active) {
      if (isSchedules()) {
        console.log("Schedules valid, proceeding with offline payment.");
        setChecked(e.target.checked);
        dispatch(setOfflineInfoStep(2)); // Debug action
        console.log("Dispatching offlineInfoStep with value 2");
        router.push(
          {
            pathname: "/checkout",
            query: { page: page, method: "offline" },
          },
          undefined,
          { shallow: true }
        );
        console.log("Navigating to checkout with offline method");
      } else {
        console.log("Store schedules are invalid, showing storeCloseToast.");
        storeCloseToast();
      }
    } else {
      console.log("Store is closed, showing storeCloseToast.");
      storeCloseToast();
    }
  };
  console.log("Cart Data in PlaceOrder Component:", props.cartList);
  const primaryColor = theme.palette.primary.main;

  return (
    <CustomStackFullWidth alignItems="center" spacing={2} >
      <FormGroup>
        {/* <FormControlLabel
          control={<Checkbox checked={checked} onChange={handleChange} />}
          label={
            <CustomTypography fontSize="12px">
              {t(`I agree that placing the order places me under`)}{" "}
              <Link href="/terms-and-conditions" style={{ color: primaryColor }}>
                {t("Terms and Conditions")}
              </Link>{" "}
              {t("&")}
              <Link href="/privacy-policy" style={{ color: primaryColor }}>
                {" "}
                {t("Privacy Policy")}
              </Link>
            </CustomTypography>
          }
        /> */}
      </FormGroup>

      {offlineInfoStep === 0 ? (
        <LoadingButton
          sx={{
            background: `linear-gradient(135deg, #FF6600, #FF9900)`,
            " &:hover": { background: "#f06102" },
          }}
          type="submit"
          fullWidth
          variant="contained"
          onClick={() => {
            console.log("Place Order clicked");
            console.log("Checked:", checked); // Log checkbox state
            console.log("Order Loading:", orderLoading);
            console.log("isLoading:", isLoading);
            placeOrder(); // Execute placeOrder function
          }}
          loading={orderLoading || isLoading}
          // disabled={!checked}
        >
          {t("Place Order")}
        </LoadingButton>
      ) : (
        <LoadingButton
          fullWidth
          variant="contained"
          sx={{
            backgroundColor: "#ff9900",
            "&:hover": { backgroundColor: "#e68a00" },
          }}
          onClick={handleOffline}
          loading={orderLoading || isLoading}
          disabled={!checked}
        >
          {t("Confirm Order")}
        </LoadingButton>
      )}
    </CustomStackFullWidth>
  );
};

PlaceOrder.propTypes = {};

export default PlaceOrder;
