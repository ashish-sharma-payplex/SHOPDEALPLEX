import InfoIcon from "@mui/icons-material/Info";
import {
  Checkbox,
  FormControlLabel,
  Grid,
  Skeleton,
  Stack,
  Tooltip,
  Typography,
} from "@mui/material";
import { useEffect, useMemo, useState } from "react";
import { useTheme } from "@mui/material/styles";
import { Box, alpha } from "@mui/system";
import {
  getAmountWithSign,
  getReferDiscount,
} from "helper-functions/CardHelpers";
import { getToken } from "helper-functions/getToken";
import { useTranslation } from "react-i18next";
import { useDispatch, useSelector } from "react-redux";
import { setTotalAmount } from "redux/slices/cart";
import { CustomStackFullWidth } from "styled-components/CustomStyles.style";
import {
  bad_weather_fees,
  getCouponDiscount,
  getDeliveryFees,
  getProductDiscount,
  getSubTotalPrice,
  getTaxableTotalPrice,
  handlePurchasedAmount,
} from "utils/CustomFunctions";
import CustomDivider from "../../CustomDivider";
import { CalculationGrid, TotalGrid } from "../CheckOut.style";

const OrderCalculation = (props) => {
  const {
    cartList,
    normalizedCartList,
    storeData,
    couponDiscount,
    distanceData,
    configData,
    orderType,
    deliveryTip,
    origin,
    destination,
    zoneData,
    setDeliveryFee,
    extraCharge,
    usePartialPayment,
    walletBalance,
    setPayableAmount,
    additionalCharge,
    payableAmount,
    cashbackAmount,
    handleExtraPackaging,
    isPackaging,
    packagingCharge,
    customerData,
    initVauleEx,
    isLoading,
  } = props;

  const token = getToken();
  const { t } = useTranslation();
  const theme = useTheme();
  const dispatch = useDispatch();
  // const [freeDelivery, setFreeDelivery] = useState("false");
  const { profileInfo } = useSelector((state) => state.profileInfo);
  const tempExtraCharge = extraCharge ?? 0;
  const couponType = "coupon";

  const effectiveCartList =
    Array.isArray(cartList) &&
      cartList.length > 0 &&
      (
        cartList[0]?.food_variations?.length > 0 ||
        cartList[0]?.product?.addons?.length > 0
      )
      ? cartList
      : normalizedCartList;


  const normalizedEffectiveCartList = effectiveCartList.map(item => {
    // ✅ BUY NOW variation → CART SHAPE
    if (
      (!item.food_variations || item.food_variations.length === 0) &&
      Array.isArray(item.variation)
    ) {
      item.food_variations = item.variation;
    }

    // ✅ BUY NOW addons → CART SHAPE
    if (
      (!item.product?.addons || item.product.addons.length === 0) &&
      Array.isArray(item.selectedAddons)
    ) {
      item.product = {
        ...item.product,
        addons: item.selectedAddons.map(a => ({
          ...a,
          isChecked: true
        }))
      };
    }

    return item;
  });
  const baseItemSubTotal = useMemo(() => {
    let total = 0;

    normalizedEffectiveCartList?.forEach(item => {
      const qty = Number(item.quantity || 1);

      // 🔑 ALWAYS take base product price
      const basePrice =
        Number(item?.product?.price ?? item?.price ?? 0);

      total += basePrice * qty;
    });

    return total;
  }, [normalizedEffectiveCartList]);
  /* ================= FOOD ONLY : VARIATION ================= */
  const variationSummary = useMemo(() => {
    let count = 0;
    let price = 0;

    normalizedEffectiveCartList?.forEach((item) => {
      const qty = Number(item.quantity || 1);
      const variations = Array.isArray(item.food_variations)
        ? item.food_variations
        : [];

      variations.forEach((variation) => {
        const values = Array.isArray(variation.values_to_show)
          ? variation.values_to_show
          : [];

        values.forEach((v) => {
          if (v?.isSelected) {
            console.log("✅ SELECTED VARIATION:", v.label, v.optionPrice);
            count += qty;
            price += Number(v.optionPrice || 0) * qty;
          }
        });
      });
    });

    return { count, price };
  }, [normalizedEffectiveCartList]);




  /* ================= FOOD ONLY : ADDON ================= */
  const addonSummary = useMemo(() => {
    let count = 0;
    let price = 0;

    normalizedEffectiveCartList?.forEach((item) => {
      const qty = Number(item.quantity || 1);
      const addons = Array.isArray(item.product?.addons)
        ? item.product.addons
        : [];

      addons.forEach((addon) => {
        if (addon?.isChecked && addon.quantity > 0) {
          console.log("✅ SELECTED ADDON:", addon.name, addon.price, addon.quantity);

          count += addon.quantity * qty;
          price += Number(addon.price || 0) * addon.quantity * qty;
        }
      });
    });

    return { count, price };
  }, [normalizedEffectiveCartList]);


  console.group("🧪 ORDER CALC DEBUG");

  console.log("RAW cartList 👉", cartList);
  console.log("NORMALIZED cart 👉", normalizedCartList);
  console.log("EFFECTIVE cart 👉", effectiveCartList);

  normalizedEffectiveCartList?.forEach((item, idx) => {
    console.log(`🟢 ITEM ${idx}`);

    console.log("quantity:", item.quantity);
    console.log("food_variations:", item.food_variations);

    item.food_variations?.forEach((v, i) => {
      console.log(`  🔸 variation ${i}:`, v.name);
      console.log("  values_to_show:", v.values_to_show);
    });

    console.log("addons:", item.product?.addons);
  });

  console.groupEnd();





  /* ================= REAL SUBTOTAL ================= */
  const realSubTotal =
    getSubTotalPrice(normalizedEffectiveCartList) +
    variationSummary.price +
    addonSummary.price;
  /* ================= DELIVERY FEE ================= */
  //   const handleDeliveryFee = () => {
  //   const price = Number(
  //     getDeliveryFees(
  //       storeData,
  //       configData,
  //       cartList,
  //       distanceData?.data,
  //       couponDiscount,
  //       couponType,
  //       orderType,
  //       zoneData,
  //       origin,
  //       destination,
  //       tempExtraCharge
  //     ) || 0
  //   );

  //   // ✅ delivery me fee lagegi, pickup me 0
  //   const finalFee = orderType === "delivery" ? price : 0;

  //   setDeliveryFee(finalFee);

  //   if (finalFee === 0) {
  //     return <Typography>{t("Free")}</Typography>;
  //   }

  //   return (
  //     <Stack direction="row" justifyContent="flex-end" spacing={0.5}>
  //       <Typography>(+)</Typography>
  //       <Typography>{getAmountWithSign(finalFee)}</Typography>
  //     </Stack>
  //   );
  // };

  /* ================= DELIVERY FEE ================= */
  const deliveryFee = useMemo(() => {
    if (orderType !== "delivery") return 0;

    return Number(
      getDeliveryFees(
        storeData,
        configData,
        cartList,
        distanceData?.data,
        couponDiscount,
        couponType,
        orderType,
        zoneData,
        origin,
        destination,
        tempExtraCharge
      ) || 0
    );
  }, [
    storeData,
    configData,
    cartList,
    distanceData,
    couponDiscount,
    orderType,
    zoneData,
    origin,
    destination,
    tempExtraCharge,
  ]);


  useEffect(() => {
    setDeliveryFee(deliveryFee);
  }, [deliveryFee]);

  /* ================= COUPON ================= */
  const handleCouponDiscount = () => {
    const value = getCouponDiscount(couponDiscount, storeData, cartList);

    if (couponDiscount?.coupon_type === "free_delivery") {
      setFreeDelivery("true");
      return 0;
    }
    return getAmountWithSign(value);
  };

  /* ================= REFER DISCOUNT ================= */
  const totalAmountForRefer = couponDiscount
    ? handlePurchasedAmount(cartList) -
    getProductDiscount(cartList, storeData) -
    getCouponDiscount(couponDiscount, storeData, cartList)
    : handlePurchasedAmount(cartList) -
    getProductDiscount(cartList, storeData);

  const referDiscount = getReferDiscount(
    totalAmountForRefer,
    customerData?.data?.discount_amount,
    customerData?.data?.discount_amount_type
  );


  console.log("TAX DEBUG", {
    cartList,
    normalizedEffectiveCartList,
    taxableFromFn: getTaxableTotalPrice(
      normalizedEffectiveCartList,
      couponDiscount,
      storeData,
      referDiscount
    ),
  });
  /* ================= FINAL TOTAL ================= */
  const calculateTotalAmount = () => {
    const discount = Number(
      getProductDiscount(cartList, storeData) || 0
    );

    const coupon = Number(
      getCouponDiscount(couponDiscount, storeData, cartList) || 0
    );

    const tax = Number(
      getTaxableTotalPrice(
        normalizedEffectiveCartList,
        couponDiscount,
        storeData,
        referDiscount
      ) || 0
    );

    return (
      Number(realSubTotal) -
      discount -
      coupon +
      tax +
      Number(deliveryFee || 0) +   // ✅ ADD THIS
      Number(deliveryTip || 0) +
      Number(additionalCharge || 0) +
      Number(packagingCharge || 0)
    );

  };



  const discountedPrice = getProductDiscount(cartList, storeData);


  const finalTotalAmount = useMemo(() => {
    const total = Number(calculateTotalAmount()) || 0;
    return profileInfo?.is_valid_for_discount
      ? total - referDiscount
      : total;
  }, [
    realSubTotal,
    couponDiscount,
    deliveryFee,      // ✅ add
    deliveryTip,
    additionalCharge,
    packagingCharge,
    referDiscount,
    profileInfo,
  ]);



  useEffect(() => {
    if (Number.isFinite(finalTotalAmount)) {
      setPayableAmount(finalTotalAmount);
      dispatch(setTotalAmount(finalTotalAmount));
    }
  }, [finalTotalAmount]);


  const totalAmountAfterPartial =
    finalTotalAmount - walletBalance;



  console.log("TOTAL DEBUG", {
    realSubTotal,
    discount: discountedPrice,
    deliveryFee,
    deliveryTip,
    finalTotalAmount,
  });

const newPrice = baseItemSubTotal && discountedPrice
      ? (baseItemSubTotal - discountedPrice)
      : baseItemSubTotal;

  /* ================= UI ================= */
  return (


    <>

      <Stack
        direction="row"
        alignItems="center"
        width="100%"
        spacing={2}
        mb={1}
      >
        <Typography
          fontSize="18px"
          fontWeight={600}
          color="#000"
          whiteSpace="nowrap"
        >
          {t("Order Summary")}
        </Typography>

        <Stack
          flex={1}
          height="3px"
          sx={{
            background:
              "linear-gradient(to right, #e0e0e0 0%, #e0e0e0 60%, rgba(224,224,224,0) 100%)",
          }}
        />
      </Stack>

      <CalculationGrid
        container
        item
        xs={12}
        spacing={1}
        mt="1rem"
        sx={{
          background: "#fff",
          borderRadius: "12px",
          padding: "12px",
          border: "1px solid rgba(0,0,0,0.12)", // 👈 actual border
          m: 0.5,
        }}
      >

        {/* Items Price */}
        <Grid item xs={8}>
          {cartList.length > 1 ? t("Items Price") : t("Item Price")}
        </Grid>
        <Grid item xs={4} align="right">
        <Stack
          direction="row"
          justifyContent="flex-end"
          alignItems="center"
          spacing={1}
        >
          {/* Original variation price */}
          <Typography sx={{ color:"#1A914B", fontWeight:500 }}>
            {getAmountWithSign(newPrice)}
          </Typography>
          {/* Discounted price */}
          <Typography
            sx={{
              textDecoration:"line-through",
              color:"#ADADAD",
              fontSize:"0.85rem",
            }}
          >
            {getAmountWithSign(baseItemSubTotal)}
          </Typography>
        </Stack>
      </Grid>


        {/* FOOD : Variation */}
        {variationSummary.count > 0 && (
          <>
            <Grid item xs={8}>
              {t("Variation")} x{variationSummary.count}
            </Grid>
            <Grid item xs={4} align="right">
              {getAmountWithSign(variationSummary.price)}
            </Grid>
          </>
        )}

        {/* FOOD : Addon */}
        {addonSummary.count > 0 && (
          <>
            <Grid item xs={8}>
              {t("Add On")} x{addonSummary.count}
            </Grid>
            <Grid item xs={4} align="right">
              {getAmountWithSign(addonSummary.price)}
            </Grid>
          </>
        )}

        {/* Discount */}
        <Grid item xs={8}>{t("Discount")}</Grid>
        <Grid item xs={4} align="right">
          (-) {getAmountWithSign(discountedPrice)}
        </Grid>

        {/* Coupon */}
        {couponDiscount && (
          <>
            <Grid item xs={8}>{t("Coupon Discount")}</Grid>
            <Grid item xs={4} align="right">
              {couponDiscount.coupon_type === "free_delivery"
                ? t("Free Delivery")
                : `(-) ${handleCouponDiscount()}`}
            </Grid>
          </>
        )}

        {/* TAX */}
        {storeData?.tax && (
          <>
            <Grid item xs={8}>
              {t("TAX")} ({storeData.tax}%)
            </Grid>
            <Grid item xs={4} align="right">
              (+){" "}
              {getAmountWithSign(
                getTaxableTotalPrice(
                  normalizedEffectiveCartList,
                  couponDiscount,
                  storeData,
                  referDiscount
                )
              )}
            </Grid>
          </>
        )}

        {/* Delivery Tip */}
        {Number(configData?.dm_tips_status) === 1 && (
          <>
            <Grid item xs={8}>{t("Deliveryman tips")}</Grid>
            <Grid item xs={4} align="right">
              (+) {getAmountWithSign(deliveryTip)}
            </Grid>
          </>
        )}

        {/* Delivery Fee */}
        <Grid item xs={8}>{t("Delivery fee")}</Grid>
        <Grid item xs={4} align="right">
          {deliveryFee === 0 ? (
            <Typography>{t("Free")}</Typography>
          ) : (
            <Stack direction="row" justifyContent="flex-end" spacing={0.5}>
              <Typography>(+)</Typography>
              <Typography>{getAmountWithSign(deliveryFee)}</Typography>
            </Stack>
          )}
        </Grid>

        <CustomDivider border="1px" />

        {/* TOTAL */}
        
          <Grid item xs={8} fontWeight={700} color="#1A914B">
            {t("To Pay")}
          </Grid>
          <Grid item xs={4} align="right" fontWeight={700} color="#1A914B">
            {getAmountWithSign(
              Number.isFinite(finalTotalAmount) ? finalTotalAmount : 0
            )}
          </Grid>

      

        {/* Partial payment */}
        {usePartialPayment && payableAmount > walletBalance && (
          <>
            <Grid item xs={8}>{t("Paid by wallet")}</Grid>
            <Grid item xs={4} align="right">
              (-) {getAmountWithSign(walletBalance)}
            </Grid>

            <Grid item xs={8}>{t("Due Payment")}</Grid>
            <Grid item xs={4} align="right">
              {getAmountWithSign(totalAmountAfterPartial)}
            </Grid>
          </>
        )}

        {/* Cashback */}
        {token && cashbackAmount?.cashback_amount > 0 && (
          <Grid item xs={12}>
            <Box
              borderLeft={`2px solid ${theme.palette.primary.main}`}
              padding="0.5rem"
              backgroundColor={alpha(theme.palette.primary.main, 0.05)}
            >
              {t("You will receive cashback")}
            </Box>
          </Grid>
        )}
      </CalculationGrid>
    </>
  );
};

export default OrderCalculation;
