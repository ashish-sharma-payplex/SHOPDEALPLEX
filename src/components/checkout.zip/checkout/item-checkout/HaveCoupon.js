import React, { useEffect, useState } from "react";
import { Grid, InputBase, Dialog, DialogActions, DialogContent, DialogTitle, Button, Stack, Typography } from "@mui/material";
import { useQuery } from "react-query";
import { useTranslation } from "react-i18next";
import { toast } from "react-hot-toast";
import { useDispatch, useSelector } from "react-redux";
import { useTheme } from "@mui/material/styles";
import { CouponApi } from "api-manage/another-formated-api/couponApi";
import { onErrorResponse } from "api-manage/api-error-response/ErrorResponses";
import { setCouponInfo, setCouponType } from "redux/slices/profileInfo";
import { coupon_minimum } from "utils/toasterMessages";
import { getAmountWithSign } from "helper-functions/CardHelpers";
import HadCouponBox from "./HadCouponBox";
import { InputField } from "../CheckOut.style";

const HaveCoupon = (props) => {
  const {
    store_id,
    setCouponDiscount,
    couponDiscount,
    totalAmount,
    deliveryFee,
    deliveryTip,
    setSwitchToWallet,
    payableAmount,
    walletBalance,
  } = props;

  const theme = useTheme();
  const { couponInfo } = useSelector((state) => state.profileInfo);
  const [couponCode, setCouponCode] = useState(couponInfo?.code);
  const [openDialog, setOpenDialog] = useState(false);  // State to open the dialog
  const { t } = useTranslation();
  const dispatch = useDispatch();
  let zoneId;

  if (typeof window !== "undefined") {
    zoneId = JSON.parse(localStorage.getItem("zoneid"));
  }

  const getCouponDiscount = (discount, discountType, totalAmountOverall) => {
    if (discountType === "amount") {
      return discount;
    } else {
      return (discount / 100) * totalAmountOverall;
    }
  };

  const handleSuccess = (response) => {
    const totalAmountOverall = totalAmount - deliveryFee - deliveryTip;
    if (
      Number.parseInt(response?.data?.min_purchase) <=
      Number.parseInt(totalAmountOverall)
    ) {
      if (response?.data?.discount_type === "percent") {
        dispatch(setCouponInfo(response.data));
        toast.success(t("Coupon Applied"));
        dispatch(setCouponType(response.data.coupon_type));
        setCouponDiscount({ ...response.data, zoneId: zoneId });
      } else {
        if (
          response?.data?.discount &&
          payableAmount >= response?.data?.discount
        ) {
          dispatch(setCouponInfo(response.data));
          toast.success(t("Coupon Applied"));
          dispatch(setCouponType(response.data.coupon_type));
          setCouponDiscount({ ...response.data, zoneId: zoneId });
        } else {
          toast.error(t("Your total price must be more than the coupon amount"));
        }
      }
    } else {
      toast.error(
        `${t(coupon_minimum)} ${getAmountWithSign(
          response?.data?.min_purchase
        )}`
      );
    }
  };

  const { isLoading, refetch } = useQuery(
    "apply-coupon",
    () => CouponApi.applyCoupon(couponCode, store_id),
    {
      onSuccess: handleSuccess,
      onError: onErrorResponse,
      enabled: false,
      retry: 1,
    }
  );

  useEffect(() => {
    return () => {
      dispatch(setCouponInfo(null));
    };
  }, []);

  const removeCoupon = () => {
    setCouponDiscount(null);
    localStorage.removeItem("coupon");
    setCouponCode(null);
    dispatch(setCouponInfo(null));
    setSwitchToWallet(false);
  };

  const handleApply = async () => {
    await refetch();
    setOpenDialog(false); // Close dialog after applying coupon
  };

  const borderColor = theme.palette.primary.main;

  return (
    <>
     <Stack
            direction="row"
            alignItems="center"
            width="100%"
            spacing={2}
            mb={0.5}
          >
            <Typography
              fontSize="18px"
              fontWeight={600}
              color="#000"
              whiteSpace="nowrap"
            >
              Redeem {/* Display only showingTitle */}
            </Typography>
            <Stack
              flex={1}
              height="3px"
              sx={{
                background:
                  "linear-gradient(to right, #e0e0e0 0%, #e0e0e0 60%, rgba(224,224,224,0) 100%)",
              }}
            />
          </Stack>
      <Grid
        container
        justifyContent="flex-start"
        pt="16px"
        pb="10px"
        spacing={1}
      >
        {couponInfo ? (
          <Grid item xs={12} sm={12} md={12}>
            <HadCouponBox removeCoupon={removeCoupon} couponInfo={couponInfo} />
          </Grid>
        ) : (
          <Grid
            item
            md={12} // Full width
            xs={12}
            sm={12}
            pr={{ xs: "0px", sm: "8px", md: "8px" }}
            pb={{ xs: "8px", sm: "0px", md: "0px" }}
            onClick={() => setOpenDialog(true)}  // Open dialog on click
            sx={{
              border: "1px solid #e0e0e0", // Border to match the design
              borderRadius: "8px",
              padding: "14px 16px", // Increased padding for more height
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              cursor: "pointer",
              width: "100%", // Ensuring full width
              "&:hover": {
                backgroundColor: "#f5f5f5", // Hover effect
              },
            }}
          >
            <Grid container justifyContent="space-between" alignItems="center" sx={{ width: "100%" }}>
              <Grid item display="flex" alignItems="center">
                {/* Use an image tag to reference the SVG from the public folder */}
                <img
                  src="/Discount1.svg" // Replace with the relative path to your SVG
                  alt="Apply Offer Icon"
                  style={{ width: "20px", height: "20px", marginRight: "8px" }}
                />
                <span style={{ fontSize: "14px", color: "#3C3C3C" }}>Apply offer</span>
              </Grid>
              <Grid item>
                {/* The arrow icon now placed on the far right */}
                <span style={{ fontSize: "30px", color: "#3c3c3c" }}>›</span>
              </Grid>
            </Grid>
          </Grid>

        )}
      </Grid>

      {/* Dialog for coupon input and apply button */}
      <Dialog open={openDialog} onClose={() => setOpenDialog(false)}>
        <DialogTitle>Apply Coupon</DialogTitle>
        <DialogContent>
          <Grid container spacing={2}>


            <Grid item xs={12}>
              <InputField
                variant="outlined"
                sx={{
                  height: "100%",
                  border: `1px solid #FF6600`, // Border color matching the design
                  borderRadius: "5px",
                }}
              >
                <InputBase
                  placeholder={t("Enter Your Coupon..")}
                  sx={{
                    flex: 1,
                    width: "100%",
                    padding: "5px 10px 5px",
                    [theme.breakpoints.down("sm")]: {
                      fontSize: "12px",
                    },
                  }}
                  onChange={(e) => setCouponCode(e.target.value)}
                  value={couponCode ? couponCode : ""}
                  onKeyPress={(e) => {
                    if (e.key === "Enter") {
                      handleApply();
                    }
                  }}
                />
              </InputField>
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenDialog(false)} color="primary">
            Cancel
          </Button>
          <Button
            onClick={handleApply}
            color="primary"
            disabled={couponCode === "" || !couponCode}
          >
            Apply
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default HaveCoupon;
