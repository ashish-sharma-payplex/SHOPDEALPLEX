import { Grid, Stack, Typography, Button, IconButton } from "@mui/material";
import Skeleton from "@mui/material/Skeleton";
import { useTheme } from "@mui/material/styles";
import { Box } from "@mui/system";
import AddIcon from "@mui/icons-material/Add";
import RemoveIcon from "@mui/icons-material/Remove";
import { useDispatch } from "react-redux";
import { setCartList, setIncrementToCartItem, setDecrementToCartItem } from "../../../redux/slices/cart";
import { useRouter } from "next/router";
import { getAmountWithSign } from "../../../helper-functions/CardHelpers";
import { CustomStackFullWidth } from "../../../styled-components/CustomStyles.style";
import { handleProductValueWithOutDiscount } from "../../../utils/CustomFunctions";
import CustomImageContainer from "../../CustomImageContainer";
import VariationContent from "../../added-cart-view/VariationContent";
import {
  OrderFoodAmount,
  OrderFoodName,
  OrderFoodSubtitle,
} from "../CheckOut.style";

export const VegNonveg = ({ theme, item, t }) => {
  return (
    <Stack
      sx={{
        position: "absolute",
        bottom: 0,
        left: 0,
        width: "100%",
        background: (theme) => theme.palette.primary.overLay,
        opacity: "0.6",
        padding: "10px",
        height: "30%",
        alignItems: "center",
        justifyContent: "center",
        borderBottomRightRadius: "10px",
        borderBottomLeftRadius: "10px",
      }}
    >
      <Typography align="center" color={theme.palette.neutral[100]}>
        {item?.veg === 0 ? t("Non-Veg") : t("Veg")}
      </Typography>
    </Stack>
  );
};

const RegularOrders = (props) => {
  const { configData, cartList, t, isSmall } = props;
  const theme = useTheme();
  const productBaseUrl = configData?.base_urls?.item_image_url;
  const dispatch = useDispatch();
  const router = useRouter();

  /* =====================================================
   READ MODULE FROM LOCALSTORAGE
  ===================================================== */
  const moduleData = JSON.parse(localStorage.getItem("module"));
  const currentModuleType = moduleData?.module_type;

  const getUpdatedPrice = (item, qty) => {
    const isFood = currentModuleType === "food";
    const base = isFood ? item.price : item?.selectedOption?.[0]?.price ?? item.price;

    // Apply discount if available
    const discount = item.discount || 0;
    const discountType = item.discount_type || "percent"; // default to percentage

    let finalPrice = base * qty;

    if (discount > 0) {
      if (discountType === "percent") {
        finalPrice = finalPrice - (finalPrice * discount) / 100;
      } else {
        finalPrice = finalPrice - discount;
      }
    }

    return finalPrice;
  };

  const getBaseItemPrice = (item) => {
    const isFood = currentModuleType === "food";

    // Food module: item.price hi base hota hai
    if (isFood) {
      return item.price;
    }

    // Other modules: selected option ka price ya fallback
    return item?.selectedOption?.[0]?.price ?? item.price;
  };

  /* ================= HANDLE INCREASE QUANTITY ================= */
  const handleIncreaseQuantity = (index) => {
    const updatedItem = cartList[index];
    const newQty = updatedItem.quantity + 1;
    const newTotalPrice = getUpdatedPrice(updatedItem, newQty);

    const updatedItemData = {
      ...updatedItem,
      quantity: newQty,
      totalPrice: newTotalPrice,
      cartItemKey: updatedItem.cartItemKey,
      cartItemId: updatedItem.cartItemId,
    };

    dispatch(setIncrementToCartItem(updatedItemData)); // Redux update for increment
  };

  /* ================= HANDLE DECREASE QUANTITY ================= */
  const handleDecreaseQuantity = (index) => {
    const updatedItem = cartList[index];
    const newQty = updatedItem.quantity - 1;

    if (newQty === 0) {
      // If quantity reaches 0, remove the item
      dispatch(setRemoveItemFromCart({ cartItemKey: updatedItem.cartItemKey, cartItemId: updatedItem.cartItemId }));
      return;
    }

    const newTotalPrice = getUpdatedPrice(updatedItem, newQty);

    const updatedItemData = {
      ...updatedItem,
      quantity: newQty,
      totalPrice: newTotalPrice,
      cartItemKey: updatedItem.cartItemKey,
      cartItemId: updatedItem.cartItemId,
    };

    dispatch(setDecrementToCartItem(updatedItemData)); // Redux update for decrement
  };

  const handleAddMoreItems = () => {
    router.push("/home"); // or your product listing page
  };

  return (
    <>


      {cartList.length > 0 ? (
        cartList.map((item, index) => {

          const variationText =
            currentModuleType === "food"
              ? item?.variation
                ?.flatMap(v =>
                  v?.values_to_show
                    ?.filter(val => val.isSelected)
                    ?.map(val => val.label)
                )
                ?.join(", ")
              : "";

          const addonText =
            item?.addons
              ?.filter(a => a.isChecked)
              ?.map(a => a.name)
              ?.join(", ") || "";

          return (
            <Stack
              key={index}
              direction="row"
              alignItems="center"
              justifyContent="space-between"
              width="100%"              // ✅ ADD THIS
              sx={{
                background: "#fff",
                borderRadius: "12px",
                padding: "12px",
                boxShadow: "0 1px 6px rgba(0,0,0,0.08)",
                mx: 0.5,
                mb:1
              }}
            >

              {/* LEFT IMAGE */}
              <Stack
                sx={{
                  width: 55,
                  height: 55,
                  borderRadius: "8px",
                  overflow: "hidden",
                  border: "1px solid #eee",
                }}
              >
                <CustomImageContainer
                  src={item?.image_full_url}
                  height="100%"
                  width="100%"
                />
              </Stack>

              {/* CENTER CONTENT */}
              <Stack flex={1} ml={1.5} spacing={0.4}>
                <Typography fontSize="13px" fontWeight={600}>
                  {item.name}
                </Typography>

                {variationText && (
                  <Typography fontSize="11px" color="text.secondary">
                    {variationText}
                  </Typography>
                )}

                {addonText && (
                  <Typography fontSize="11px" color="text.secondary">
                    Add on: {addonText}
                  </Typography>
                )}

                <Stack direction="row" spacing={1} alignItems="center">
                  <Typography fontSize="13px" fontWeight={600}>
                    ₹{(item.price * item.quantity).toFixed(0)}
                  </Typography>

                  {item.discount_price && (
                    <Typography
                      fontSize="11px"
                      sx={{ textDecoration: "line-through", color: "#999" }}
                    >
                      ₹{item.discount_price}
                    </Typography>
                  )}
                </Stack>
              </Stack>

              {/* RIGHT QTY BUTTON */}
              <Stack
                direction="row"
                alignItems="center"
                sx={{
                  background: "#1dbf73",
                  borderRadius: "8px",
                  px: 1,
                  height: 34,
                }}
              >
                <IconButton
                  size="small"
                  onClick={() => handleDecreaseQuantity(index)}
                  disabled={item.quantity <= 1}
                  sx={{ color: "#fff" }}
                >
                  <RemoveIcon fontSize="small" />
                </IconButton>

                <Typography
                  sx={{ color: "#fff", fontWeight: 600, px: 0.5 }}
                >
                  {item.quantity}
                </Typography>

                <IconButton
                  size="small"
                  onClick={() => handleIncreaseQuantity(index)}
                  sx={{ color: "#fff" }}
                >
                  <AddIcon fontSize="small" />
                </IconButton>
              </Stack>
            </Stack>
          );
        })
      ) : (
        <Skeleton height={70} />
      )}
    </>


  );
};

RegularOrders.propTypes = {};

export default RegularOrders;
